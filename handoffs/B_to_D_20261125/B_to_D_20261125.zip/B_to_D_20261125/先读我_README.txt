﻿B → D 交接材料（2026-11-25打包）

一、目录导航
01_B05_final/manifest.json：最终42条仿真轨迹，860步、172张合成图像、138个传感器故障正标签步。
每个episode目录：episode.json为种子/分集/配置；steps.jsonl为原始轨迹；samples.jsonl为检测视图及标签；visuals为合成图；runtime_stdout.log为原始输出。
02_B05_replay：同配置独立重跑结果，仅用于复现核对，不作为额外42条独立训练样本。
03_B07_profile/performance.csv：耗时和内存汇总；manifest.json、freeze.json、frozen_inputs/保存来源与配置；各场景summary.json为测量明细，steps.jsonl/result.json为运行记录（不同场景文件不同）。gateway_withdrawal和worker_exit为退出与网关验证。
04_source_and_companions：代码快照及此前云端保留的配套配置、变量字典、依赖锁和补丁，不含.git或虚拟环境。
05_acceptance：167项测试、文档检查及本次B05语义校验。
SHA256SUMS.json：其他全部文件的相对路径及SHA256校验值。

二、版本
https://github.com/W-create-user/L3-/tree/codex/b-20261123
SHA：db7fbe40ff2ca1b56178e58424b31e0035e663f2
本包额外附上此前未公开的配套配置，不代表这些材料已上传GitHub。请勿混用main旧适配器。

三、数据边界
全部数据来自科研仿真及合成传感器故障。标签0仅指当前步未施加预定义传感器故障，不能解释为工艺健康；physical_health_label为空，不能当正常标签。
B05偏置、噪声、缺失注入检测视图，控制器和D使用真实观测；不是物理工艺故障。图像和文本由数值派生，不提供独立信息。
按既定episode/group分集；禁止把重跑数据当独立样本，或跨训练/测试混用。
B07另测噪声进入PI，D及目标评价仍看真实状态。性能为本机小样本测量，不是工业实时性保证。失败轨迹完整保留，不能筛除后只报告成功。
C05待确认、MADDPG未训练，网络及跨角色验收未完成，R03未启用，不构成物理安全认证。

四、如何读取及复现
解压后可直接读取JSON/JSONL/CSV/PNG，不需要访问B原云端路径。日志历史绝对路径仅为来源记录。
在已安装numpy等依赖的环境进入04_source_and_companions：
python -m data_generation.validation ../01_B05_final
python -m data_generation.validation ../02_B05_replay
重跑B07须具备正确来源的MPCTools、兼容补丁、CasADi及mAb依赖：
python -m experiments.profile_b07 --output <尚不存在的新输出目录>
接收方可先读取现有结果，无需为了读文件而重跑。

五、范围
仅打包供用户转交D，未上传GitHub，未写入用户本机D盘。包含仿真轨迹、日志、云端路径及版本信息；公开发布需另行确认。
